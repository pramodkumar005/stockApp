/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

// global.url ='http://pinakininfo.co.in/MSoft/data/backendService.php?action=validateUser';
// global.registerUrl = 'http://pinakininfo.co.in/MSoft/data/backendService.php?action=registerUser';
// global.outstandingUrl = 'http://pinakininfo.co.in/MSoft/data/backendService.php?action=get_allcustomer&companyid=';
// global.productUrl = 'http://pinakininfo.co.in/MSoft/data/backendService.php?action=get_products&companyid=';
// global.salesOrder = 'http://pinakininfo.co.in/MSoft/data/backendService.php?action=saveSalesOrder&companyid=';
// global.salesOrderList = 'http://pinakininfo.co.in/MSoft/data/backendService.php?action=get_sales&companyid=';
// global.orderDelete = 'http://pinakininfo.co.in/MSoft/data/backendService.php?action=deleteEOrder&companyid=';
// global.syncOutstanding = 'http://pinakininfo.co.in/MSoft/data/backendService.php?action=syncDataCustomerOut&companyid=';
// global.syncProduct = 'http://pinakininfo.co.in/MSoft/data/backendService.php?action=syncDataProductList&companyid=';

global.url ='http://msoftindia.in/msoftapp/data/backendService.php?action=validateUser';
global.registerUrl = 'http://msoftindia.in/msoftapp/data/backendService.php?action=registerUser';
global.outstandingUrl = 'http://msoftindia.in/msoftapp/data/backendService.php?action=get_allcustomer&companyid=';
global.productUrl = 'http://msoftindia.in/msoftapp/data/backendService.php?action=get_products&companyid=';
global.salesOrder = 'http://msoftindia.in/msoftapp/data/backendService.php?action=saveSalesOrder&companyid=';
global.salesOrderList = 'http://msoftindia.in/msoftapp/data/backendService.php?action=get_sales&companyid=';
global.orderDelete = 'http://msoftindia.in/msoftapp/data/backendService.php?action=deleteEOrder&companyid=';
global.syncOutstanding = 'http://msoftindia.in/msoftapp/data/backendService.php?action=syncDataCustomerOut&companyid=';
global.syncProduct = 'http://msoftindia.in/msoftapp/data/backendService.php?action=syncDataProductList&companyid=';